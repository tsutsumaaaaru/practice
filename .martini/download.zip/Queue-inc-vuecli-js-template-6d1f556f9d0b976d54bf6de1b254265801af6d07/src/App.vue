<template lang='pug'>
  #app.layout_adsalary
    side-menu.sidemenu_adsalary(:prop="componentProps.sideMenuModel")
    router-view.content_adsalary
</template>
<script>
import SideMenu from '@/components/organisms/SideMenu/Index.vue'
import SideMenuModel from '@/components/organisms/SideMenu/SideMenu'
import SideMenuItemModel from '@/components/organisms/SideMenu/SideMenuItem';

export default {
  data () {
    return {
      componentProps: {
        sideMenuModel: [],
      }
    }
  },
  components: {
    SideMenu
  },
  created() {
    this.componentProps.sideMenuModel = new SideMenuModel([
      new SideMenuItemModel('Attendance', 'Attendance'),
      new SideMenuItemModel('Payroll', 'Payroll'),
      new SideMenuItemModel('Employee', 'Employee'),
      new SideMenuItemModel('Setting', 'Setting'),
    ])
  },
  methods: {
    childCallback(key, value) {
      switch (key) {
        case CALLBACK_KEY_ADD_PROJECT:
          this.$router.push({name: 'Create'})
          break;
        default:
          break;
      }
    },
  }
}
</script>

<style lang="stylus">
@import './stylus/main.styl'
</style>
