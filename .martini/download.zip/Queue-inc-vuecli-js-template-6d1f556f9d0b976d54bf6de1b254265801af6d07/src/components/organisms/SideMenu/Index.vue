<template lang="pug">
  .sideMenu
    .sideMenu_title.p-p8 Service name
    .sideMenu_item.p-p8(v-for="menuItem in prop.menuItems", @click="itemClick(menuItem)", :class="{ 'sideMenu_item-active': isItemActive(menuItem) }") {{ menuItem.label }}
</template>
<script>
import { Component, Vue } from 'vue-property-decorator';
import Model from './SideMenu';

@Component({
  name: 'SideMenu',
  props: {
    prop: Model
  },
  methods: {
    itemClick(item) {
      console.log(item)
      this.$router.push({ name: item.href})
    },
    isItemActive(item) {
      return item.href === this.$route.name
    }
  }
})
export default class SideMenu extends Vue {}
</script>
