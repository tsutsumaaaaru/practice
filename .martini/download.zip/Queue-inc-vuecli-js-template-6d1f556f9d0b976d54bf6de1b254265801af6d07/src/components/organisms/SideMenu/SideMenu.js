import SideMenuItem from './SideMenuItem'

export default class SideMenu {
  constructor(menuItems) {
    this.menuItems = menuItems
  }
}
