export default class SideMenuItem {
  constructor(label, href) {
    this.label = label
    this.href = href
  }
}
