export default class TableData {
  constructor(headerLabels, propKeys, data) {
    this.headerLabels = headerLabels
    this.propKeys = propKeys
    this.data = data
  }
}
