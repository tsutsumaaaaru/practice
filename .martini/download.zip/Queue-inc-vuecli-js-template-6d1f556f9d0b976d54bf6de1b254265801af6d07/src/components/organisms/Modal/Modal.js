export default class Modal {
  constructor(
    id,
    classes,
    animation,
    open,
  ) {
    this.id = id;
    this.classes = classes;
    this.animation = animation;
    this.open = open;
  }
}
