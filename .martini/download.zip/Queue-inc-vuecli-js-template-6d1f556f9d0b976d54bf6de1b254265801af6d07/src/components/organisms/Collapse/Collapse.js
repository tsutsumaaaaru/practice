export default class Collapse {
  constructor(
    id,
    classes,
    animation,
    open
  ) {
    this.id = id
    this.classes = classes
    this.animation = animation
    this.open = open
  }
}
