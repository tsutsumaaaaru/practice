export default class Tab {
  constructor(
    id,
    classes,
    tabItemClasses,
    tabActiveClasses
  ) {
    this.id = id
    this.classes = classes
    this.tabItemClasses = tabItemClasses
    this.tabActiveClasses = tabActiveClasses
  }
}
