export default class TabItem {
  constructor(
    id,
    classes,
    label,
    callbackKey,
    callback
  ) {
    this.id = id
    this.classes = classes
    this.label = label
  }
}
