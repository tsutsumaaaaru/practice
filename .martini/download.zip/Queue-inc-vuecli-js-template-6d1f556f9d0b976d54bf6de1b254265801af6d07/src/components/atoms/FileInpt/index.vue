<template lang="pug">
label(:class="prop.classes") {{prop.label}}
  input(:id="prop.id", type="file" ,@change="prop.callback(prop.callbackKey, $event, prop.id)", style="display: none;", :placeholder="prop.placeholder")
</template>

<script>
import { Component, Vue } from 'vue-property-decorator'
import Model from './FileInpt'

@Component({
  props: {
    prop: {
      type: Model,
    }
  }
})
export default class FileInpt extends Vue {}
</script>
