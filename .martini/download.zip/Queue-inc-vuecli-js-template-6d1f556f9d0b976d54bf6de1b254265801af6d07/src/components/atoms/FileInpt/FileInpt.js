export default class FileInpt {
  constructor(
    id,
    classes,
    label,
    placeholder,
    callbackKey,
    callback,
  ) {
    this.id = id
    this.classes = classes
    this.label = label
    this.placeholder = placeholder
    this.callbackKey = callbackKey
    this.callback = callback
  }
}
