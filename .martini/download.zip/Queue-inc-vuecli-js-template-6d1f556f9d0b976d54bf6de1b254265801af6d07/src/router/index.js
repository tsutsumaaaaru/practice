import Vue from 'vue';
import Router from 'vue-router';
import Components from '@/pages/Components.vue';
import Layout from '@/pages/Layout.vue';

Vue.use(Router)

function authValidater () {
  if (localStorage.getItem('session') !== null) {
    // return
  } else {
    return '/signin'
  }
}

export default new Router({
  mode: 'history',
  routes: [
    { path: '/', redirect: { name: 'Components' }},
    {
      path: '/components',
      name: 'Components',
      component: Components,
    },
    {
      path: '/layout',
      name: 'Layout',
      component: Layout,
    }
  ],
})
